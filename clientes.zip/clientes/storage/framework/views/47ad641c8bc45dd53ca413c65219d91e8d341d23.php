<?php $__env->startSection('content'); ?>

<div class="col-sm-10">
	<h2>
		Listado de Clientes
		<a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-primary pull-right">Nuevo</a>
	</h2>

	<?php echo $__env->make('clientes.fragments.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<table class="table table-hover table-striped">
		<thead>
			<tr>
				<th width="20px">ID</th>
				<th>Nombre</th>
				<th>Fecha de Nacimiento</th>
				<th>Dirección</th>
				<th>Estudio a realizar</th>
				<th colspan="2">&nbsp;</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($cliente->id); ?></td>
				<td><?php echo e($cliente->nombre . ' '. $cliente->apellido_paterno . ' '. $cliente->apellido_materno); ?></td>
				<td><?php echo e(Carbon\Carbon::parse($cliente->fecha_nacimiento)->format('d/m/Y')); ?></td>
				<td><?php echo e('Calle '.$cliente->calle .' No. Ext. '.$cliente->num_ext. ' Colonia '.$cliente->colonia .' CP. '.$cliente->codigo_postal .' '.$cliente->ciudad .' '.$cliente->estado); ?></td>
				<td><?php echo e($cliente->estudio); ?></td>
				
				<td>
					<a href="<?php echo e(route('clientes.edit',$cliente->id)); ?>" class="btn btn-primary"> Editar</a>
				</td>
				<td>
					<form action="<?php echo e(route('clientes.destroy', $cliente->id)); ?>" method="POST", onclick="return confirm('¿Esta seguro de eliminar?')" >
						<?php echo e(csrf_field()); ?> <!--seguridad-->
						<input type="hidden" name="_method" value="DELETE"></input>
						<button class="btn btn-danger">Borrar</button>
					</form>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	

</div>
<div class="col-sm-2">

<?php echo $__env->make('clientes.fragments.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>