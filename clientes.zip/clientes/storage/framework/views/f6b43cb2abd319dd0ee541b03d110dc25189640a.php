<div class="form-group">
	<?php echo Form::label('nombre', 'Nombre'); ?>

	<?php echo Form::text('nombre', null, ['class' => 'form-control']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('apellido_paterno', 'Apellido Paterno'); ?>

	<?php echo Form::text('apellido_paterno', null, ['class' => 'form-control']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('apellido_materno', 'Apellido Materno'); ?>

	<?php echo Form::text('apellido_materno', null, ['class' => 'form-control']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('fecha_nacimiento', 'Fecha de Nacimiento'); ?>

	<?php echo Form::text('fecha_nacimiento', Carbon\Carbon::parse($cliente->fecha_nacimiento)->format('d/m/Y') , ['id' =>'fecha_nacimiento','class' => 'form-control']); ?>

</div>


<div class="form-group">
<?php echo Form::label('direccion', 'Dirección'); ?>

</div>
<div class="form-group">

	<?php echo Form::label('calle', 'Calle'); ?>

	<?php echo e(Form::hidden('calle_id', $cliente->calle_id, array('id' => 'calle_id'))); ?>

	
    <?php echo e(Form::text('calle', $cliente->calle, ['id' => 'calle', 'placeholder' => 'Seleccionar calle', 'class' => 'form-control'])); ?>

    </div>
<div class="form-group">
<?php echo Form::label('colonia', 'Colonia'); ?>

    <?php echo e(Form::text('colonia', $cliente->colonia, ['readonly'=>'readonly', 'class' => 'form-control'])); ?>

    </div>
    <div class="form-group">
    <?php echo Form::label('ciudad', 'Ciudad'); ?>

     <?php echo e(Form::text('ciudad', $cliente->ciudad, ['readonly'=>'readonly', 'class' => 'form-control'])); ?>

</div>
     <div class="form-group">
     <?php echo Form::label('estado', 'Estado'); ?>

      <?php echo e(Form::text('estado', $cliente->estado, ['readonly'=>'readonly', 'class' => 'form-control'])); ?>



</div>

<div class="form-group">
	<?php echo Form::label('num_ext', 'No. Ext.'); ?>

	<?php echo Form::text('num_ext', null, ['class' => 'form-control', 'maxlength' => 5, 'onkeypress'=>'return valida(event)' ]); ?>

</div>

<div class="form-group">
	<?php echo Form::label('codigo_postal', 'CP'); ?>

	<?php echo Form::text('codigo_postal', null, ['class' => 'form-control', 'maxlength' => 5, 'onkeypress'=>'return valida(event)' ]); ?>

</div>

<div class="form-group">
	<?php echo Form::label('estudio', 'Estudio a realizar'); ?>

	<?php echo e(Form::hidden('estudio_id', $cliente->estudio_id, array('id' => 'estudio_id'))); ?>

	
    <?php echo e(Form::text('estudio', $cliente->estudio, ['id' => 'estudio', 'placeholder' => 'Seleccionar estudio', 'class' => 'form-control'])); ?>


    </div>


<div class="form-group">
	<?php echo Form::submit('GUARDAR', ['class' => 'btn btn-primary']); ?>

	<a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-primary pull-right"> CANCELAR </a>
</div>
