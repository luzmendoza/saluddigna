<div class="form-group">
	<?php echo Form::label('nombre', 'Nombre de la ciudad'); ?>

	<?php echo Form::text('nombre', null, ['class' => 'form-control', 'maxlength' => 50]); ?>

</div>

<div class="form-group">
	<?php echo Form::label('estado', 'Nombre del estado'); ?>

	<?php echo e(Form::hidden('estado_id', $ciudad->estado_id, array('id' => 'estado_id'))); ?>

	
    <?php echo e(Form::text('estado', $ciudad->estado, ['id' => 'estado', 'placeholder' => 'Seleccionar estado', 'class' => 'form-control'])); ?>



</div>


<div class="form-group">
	<?php echo Form::submit('GUARDAR', ['class' => 'btn btn-primary']); ?>

	<a href="<?php echo e(route('ciudades.index')); ?>" class="btn btn-primary pull-right"> CANCELAR </a>
</div>
