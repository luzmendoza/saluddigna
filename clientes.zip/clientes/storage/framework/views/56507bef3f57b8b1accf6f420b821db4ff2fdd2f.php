<?php $__env->startSection('content'); ?>

<div class="col-sm-8">
	<h2>
		<?php echo e($estado->nombre); ?>

		<a href="<?php echo e(route('estados.edit', $estado->id)); ?>" class="btn btn-primary pull-right"> Editar</a>
	</h2>

</div>
<div class="col-sm-4">

<?php echo $__env->make('estados.fragments.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>