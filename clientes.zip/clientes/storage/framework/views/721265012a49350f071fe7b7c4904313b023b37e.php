<div class="form-group">
	<?php echo Form::label('nombre', 'Nombre de la Calle'); ?>

	<?php echo Form::text('nombre', null, ['class' => 'form-control', 'maxlength' => 50]); ?>

</div>

<div class="form-group">
	<?php echo Form::label('colonia', 'Nombre de la Colonia'); ?>

	<?php echo e(Form::hidden('colonia_id', $calle->colonia_id, array('id' => 'colonia_id'))); ?>

	
    <?php echo e(Form::text('colonia', $calle->colonia, ['id' => 'colonia', 'placeholder' => 'Seleccionar colonia', 'class' => 'form-control'])); ?>



</div>


<div class="form-group">
	<?php echo Form::submit('GUARDAR', ['class' => 'btn btn-primary']); ?>

	<a href="<?php echo e(route('calles.index')); ?>" class="btn btn-primary pull-right"> CANCELAR </a>
</div>
