<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Salud Digna</title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-xs-12">
			<h1 class="page-header text-center">Salud Digna</h1>
		</div>

		<?php echo $__env->yieldContent('content'); ?>

	</div>
</div>



   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

<script type="text/javascript" src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script type="text/javascript">
     $( "#estado" ).autocomplete({
            source:'<?php echo URL::route('autocomplete'); ?>',
            minlength:1,
            autoFocus:true,
            select:function(e,ui)
            {
               $('#estado').val(ui.item.value);
               $('#estado_id').val(ui.item.id);
            // $('input[name="estado_id"]').val('12');
              // alert(ui.item.id);
                //alert($('#estado_id').val());
            }
        }); 

     $( "#ciudad" ).autocomplete({
            source:'<?php echo URL::route('autocompleteCiudad'); ?>',
            minlength:1,
            autoFocus:true,
            select:function(e,ui)
            {
               $('#ciudad').val(ui.item.value);
               $('#ciudad_id').val(ui.item.id);
            // $('input[name="estado_id"]').val('12');
              // alert(ui.item.id);
                //alert($('#estado_id').val());
            }
        }); 

    $( "#colonia" ).autocomplete({
            source:'<?php echo URL::route('autocompleteColonia'); ?>',
            minlength:1,
            autoFocus:true,
            select:function(e,ui)
            {
               $('#colonia').val(ui.item.value);
               $('#colonia_id').val(ui.item.id);
            // $('input[name="estado_id"]').val('12');
              // alert(ui.item.id);
                //alert($('#estado_id').val());
            }
        }); 

    $( "#calle" ).autocomplete({
            source:'<?php echo URL::route('autocompleteCalle'); ?>',
            minlength:1,
            autoFocus:true,
            select:function(e,ui)
            {
               $('#calle').val(ui.item.value);
               $('#calle_id').val(ui.item.id);
               $('#colonia').val(ui.item.colonia);
               $('#ciudad').val(ui.item.ciudad);
               $('#estado').val(ui.item.estado);
            // $('input[name="estado_id"]').val('12');
              // alert(ui.item.id);
                //alert($('#estado_id').val());
            }
        }); 

    $( "#estudio" ).autocomplete({
            source:'<?php echo URL::route('autocompleteEstudio'); ?>',
            minlength:1,
            autoFocus:true,
            select:function(e,ui)
            {
               $('#estudio').val(ui.item.value);
               $('#estudio_id').val(ui.item.id);
            // $('input[name="estado_id"]').val('12');
              // alert(ui.item.id);
                //alert($('#estado_id').val());
            }
        }); 


 
      $( "#fecha_nacimiento" ).datepicker(
        { 
          dateFormat: "dd/mm/yy",
          changeMonth: true,
          changeYear: true,
          yearRange: "-100:+0",
                dayNames: [ "Domingo", "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado" ],
                dayNamesMin: [ "Do", "Lu", "Ma", "Mi", "Ju", "Vi", "Sa" ],
                firstDay: 1,
                gotoCurrent: true,
                monthNames: [ "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Deciembre" ],
                onSelect: function (date) {
                  $( "#fecha_nacimiento" ).val(date);
                    //alert(date);
                }
        });

function valida(e){
    tecla = (document.all) ? e.keyCode : e.which;

    //Tecla de retroceso para borrar, siempre la permite
    if (tecla==8){
        return true;
    }
        
    // Patron de entrada, en este caso solo acepta numeros
    patron =/[0-9]/;
    tecla_final = String.fromCharCode(tecla);
    return patron.test(tecla_final);
}

   </script>

</body>
</html>