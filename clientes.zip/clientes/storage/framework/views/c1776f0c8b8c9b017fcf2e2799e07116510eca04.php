<?php $__env->startSection('content'); ?>

<div class="col-sm-10">
	<h2>
		Listado de Calles
		<a href="<?php echo e(route('calles.create')); ?>" class="btn btn-primary pull-right">Nuevo</a>
	</h2>

	<?php echo $__env->make('calles.fragments.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<table class="table table-hover table-striped">
		<thead>
			<tr>
				<th width="20px">ID</th>
				<th>Nombre</th>
				<th colspan="2">&nbsp;</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $calles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $calle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($calle->id); ?></td>
				<td><?php echo e($calle->nombre); ?></td>
				
				<td>
					<a href="<?php echo e(route('calles.edit',$calle->id)); ?>" class="btn btn-primary pull-right"> Editar</a>
				</td>
				<td>
					<form action="<?php echo e(route('calles.destroy', $calle->id)); ?>" method="POST", onclick="return confirm('¿Esta seguro de eliminar?')" >
						<?php echo e(csrf_field()); ?> <!--seguridad-->
						<input type="hidden" name="_method" value="DELETE"></input>
						<button class="btn btn-danger pull-right">Borrar</button>
					</form>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php echo $calles->render(); ?>


</div>
<div class="col-sm-2">

<?php echo $__env->make('calles.fragments.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>