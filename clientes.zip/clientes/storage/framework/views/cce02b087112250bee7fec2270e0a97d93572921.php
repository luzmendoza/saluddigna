<div class="form-group">
	<?php echo Form::label('nombre', 'Nombre del estado'); ?>

	<?php echo Form::text('nombre', null, ['class' => 'form-control', 'maxlength' => 50]); ?>

</div>


<div class="form-group">
	<?php echo Form::submit('GUARDAR', ['class' => 'btn btn-primary']); ?>

	<a href="<?php echo e(route('estados.index')); ?>" class="btn btn-primary pull-right"> CANCELAR </a>
</div>