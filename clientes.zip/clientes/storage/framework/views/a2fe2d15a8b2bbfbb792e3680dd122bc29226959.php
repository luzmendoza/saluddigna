<?php $__env->startSection('content'); ?>

<div class="col-sm-8">
	<h2>
		<?php echo e($estudio->nombre); ?>

		<a href="<?php echo e(route('estudios.edit', $estudio->id)); ?>" class="btn btn-primary pull-right"> Editar</a>
	</h2>
	<p>
		<?php echo e($estudio->precio); ?>

	</p>

</div>
<div class="col-sm-4">

<?php echo $__env->make('estudios.fragments.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>