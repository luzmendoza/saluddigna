<?php $__env->startSection('content'); ?>

<div class="col-sm-8">
	<h2>
		Editar Estado
		<a href="<?php echo e(route('estados.index')); ?>" class="btn btn-primary pull-right"> Listado</a>
	</h2>
	
	<?php echo $__env->make('estados.fragments.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo Form::model($estado, ['route' => ['estados.update', $estado->id], 'method' => 'PUT']); ?>



		<?php echo $__env->make('estados.fragments.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo Form::close(); ?>


</div>
<div class="col-sm-4">

<?php echo $__env->make('estados.fragments.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>