<div class="form-group">
	<?php echo Form::label('nombre', 'Nombre de la colonia'); ?>

	<?php echo Form::text('nombre', null, ['class' => 'form-control', 'maxlength' => 50]); ?>

</div>

<div class="form-group">
	<?php echo Form::label('ciudad', 'Nombre de la ciudad'); ?>

	<?php echo e(Form::hidden('ciudad_id', $colonia->ciudad_id, array('id' => 'ciudad_id'))); ?>

	
    <?php echo e(Form::text('ciudad', $colonia->ciudad, ['id' => 'ciudad', 'placeholder' => 'Seleccionar ciudad', 'class' => 'form-control'])); ?>



</div>


<div class="form-group">
	<?php echo Form::submit('GUARDAR', ['class' => 'btn btn-primary']); ?>

	<a href="<?php echo e(route('colonias.index')); ?>" class="btn btn-primary pull-right"> CANCELAR </a>
</div>
