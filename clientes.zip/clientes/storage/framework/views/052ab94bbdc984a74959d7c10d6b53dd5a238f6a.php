<div class="form-group">
	<?php echo Form::label('nombre', 'Nombre del estudio'); ?>

	<?php echo Form::text('nombre', null, ['class' => 'form-control', 'maxlength' => 50 ]); ?>

</div>

<div class="form-group">
	<?php echo Form::label('precio', 'Precio del estudio'); ?>

	<?php echo Form::text('precio', null, ['class' => 'form-control', 'maxlength' => 9, 'onkeypress'=>'return valida(event)']); ?>

</div>

<div class="form-group">
	<?php echo Form::submit('GUARDAR', ['class' => 'btn btn-primary']); ?>

	<a href="<?php echo e(route('estudios.index')); ?>" class="btn btn-primary pull-right"> CANCELAR </a>
</div>
