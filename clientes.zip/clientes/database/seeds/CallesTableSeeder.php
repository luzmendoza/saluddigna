<?php

use Illuminate\Database\Seeder;
use  RegClientes\Calle;


class CallesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        factory(Calle::class, 3)->create();
    }
}
