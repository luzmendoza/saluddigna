<?php

use Illuminate\Database\Seeder;
use  RegClientes\Estudio;

class EstuiosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        factory(Estudio::class, 3)->create();
    }
}
