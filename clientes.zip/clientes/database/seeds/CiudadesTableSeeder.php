<?php

use Illuminate\Database\Seeder;
use  RegClientes\Ciudad;

class CiudadesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
         factory(Ciudad::class, 3)->create();
    }
}
