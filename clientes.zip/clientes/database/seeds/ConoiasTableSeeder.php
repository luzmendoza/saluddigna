<?php

use Illuminate\Database\Seeder;
use  RegClientes\Colonia;

class ConoiasTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        factory(Colonia::class, 3)->create();
    }
}
