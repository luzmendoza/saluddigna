<?php

use Illuminate\Database\Seeder;
use  RegClientes\Cliente;


class ClientesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        factory(Cliente::class, 3)->create();
    }
}
