<?php

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| Here you may define all of your model factories. Model factories give
| you a convenient way to create models for testing and seeding your
| database. Just tell the factory how a default model should look.
|
*/

/** @var \Illuminate\Database\Eloquent\Factory $factory */
$factory->define(RegClientes\User::class, function (Faker\Generator $faker) {
    static $password;

    return [
        'name' => $faker->name,
        'email' => $faker->unique()->safeEmail,
        'password' => $password ?: $password = bcrypt('secret'),
        'remember_token' => str_random(10),
    ];
});

$factory->define(RegClientes\Estudio::class, function (Faker\Generator $faker) {
   

    return [
        'nombre' => $faker->sentence(2),
        'precio' => 5,
    ];
});

$factory->define(RegClientes\Estado::class, function (Faker\Generator $faker) {
   

    return [
        'nombre' => $faker->sentence(2),
    ];
});

$factory->define(RegClientes\Ciudad::class, function (Faker\Generator $faker) {
   
    return [
        'nombre' => $faker->sentence(2),
        'estado_id' => 2,
    ];
});

$factory->define(RegClientes\Colonia::class, function (Faker\Generator $faker) {
   
    return [
        'nombre' => $faker->sentence(2),
        'ciudad_id' => 2,
    ];
});

$factory->define(RegClientes\Calle::class, function (Faker\Generator $faker) {
   
    return [
        'nombre' => $faker->sentence(2),
        'colonia_id' => 2,
    ];
});

$factory->define(RegClientes\Cliente::class, function (Faker\Generator $faker) {
   
    return [
        'nombre' => $faker->sentence(1),
        'apellido_paterno' => $faker->sentence(1),
        'apellido_materno' => $faker->sentence(1),
         'fecha_nacimiento' =>  $faker->dateTime(),
        
        'calle_id' => 2,
        'num_ext' => 123,
        'codigo_postal' => 80298,
        'estudio_id' =>3,

    ];
});