<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateClientesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clientes', function (Blueprint $table) {
            $table->increments('id');
             $table->string('nombre',50);
             $table->string('apellido_paterno',50);
             $table->string('apellido_materno',50);
             $table->dateTime('fecha_nacimiento');
             $table->integer('calle_id')->unsigned();//llave foranea no negativo
             $table->integer('num_ext');
             $table->integer('codigo_postal');
              $table->integer('estudio_id')->unsigned();//llave foranea no negativo
            $table->timestamps();
            $table->foreign('calle_id')->references('id')->on('calles');
            $table->foreign('estudio_id')->references('id')->on('estudios');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clientes');
    }
}
