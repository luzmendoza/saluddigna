<?php

namespace RegClientes;

use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    //
    protected $fillable = [
        'nombre', 'apellido_paterno','apellido_materno','fecha_nacimiento','calle_id','num_ext',
        'codigo_postal','estudio_id'
    ];
}
