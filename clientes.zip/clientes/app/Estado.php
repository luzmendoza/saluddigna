<?php

namespace RegClientes;

use Illuminate\Database\Eloquent\Model;

class Estado extends Model
{
    //
      protected $fillable = [
        'nombre'
    ];

    //relacion al modelo ciudad
   /* public function ciudades(){
        return $this->hasMany('Ciudad', 'estado_id', 'id');
    }*/
}
