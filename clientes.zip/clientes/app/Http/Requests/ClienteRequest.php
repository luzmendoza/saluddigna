<?php

namespace RegClientes\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ClienteRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //reglas de validacionn
            'nombre' => 'required|min:3|max:50',
            'apellido_paterno' => 'required|min:3|max:50',
            'apellido_materno' => 'required|min:3|max:50',
             'fecha_nacimiento' => 'required',
             'calle_id' => 'required|exists:calles,id',
             'num_ext' => 'required|numeric',
             'codigo_postal' => 'required|numeric',
            'estudio_id' => 'required|exists:estudios,id'
        ];
    }
}

?>