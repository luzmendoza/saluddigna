<?php

namespace RegClientes\Http\Controllers;

use Illuminate\Http\Request;
use RegClientes\Http\Requests\ClienteRequest;
use RegClientes\Cliente;
use RegClientes\Calle;
use RegClientes\Estudio;
use DB;
use RegClientes\Colonia;
use RegClientes\Ciudad;
use RegClientes\Estado;

class ClienteController extends Controller
{
    //
    //pagina principal
    public function index()
    {
    	//$clientes = Cliente::orderBy('id','DESC')->paginate();
      
      /*foreach ($clientes as $cliente) {
         $calle = Calle::find($cliente->calle_id);
         $estudio = Estudio::find($cliente->estudio_id);
         $cliente->calle = $calle->nombre;
         $cliente->estudio = $estudio->nombre;..
      }*/

      //echo print_r($clientes);

      $clientes = DB::table('clientes')
            ->join('calles', 'clientes.calle_id', '=', 'calles.id')
            ->join('estudios', 'clientes.estudio_id', '=', 'estudios.id')
            ->join('colonias', 'calles.colonia_id', '=', 'colonias.id')
            ->join('ciudads', 'colonias.ciudad_id', '=', 'ciudads.id')
            ->join('estados', 'ciudads.estado_id', '=', 'estados.id')
            ->select('clientes.*', 'calles.nombre AS calle', 'estudios.nombre AS estudio',
              'colonias.nombre AS colonia','ciudads.nombre AS ciudad','estados.nombre AS estado')
            ->orderBy('clientes.id', 'desc')
            ->get();
           // ->paginate();
    
    	return view('clientes.index', compact('clientes'));
    }
    //crear cliente
    public function create()
    {
       $cliente = new Cliente;
      $cliente->calle = '';
      $cliente->calle_id = 0;
      $cliente->estudio = '';
      $cliente->estudio_id = 0;
      return view('clientes.create',  compact('cliente') );
    }
    //guardar el nuevo cliente
    public function store(ClienteRequest $request)
    {
        $cliente = new Cliente;

        $cliente->nombre = $request->nombre;
        $cliente->apellido_paterno = $request->apellido_paterno;
        $cliente->apellido_materno = $request->apellido_materno;
        //$cliente->fecha_nacimiento = $request->fecha_nacimiento;
        $cliente->calle_id = $request->calle_id;
        $cliente->num_ext = $request->num_ext;
        $cliente->codigo_postal = $request->codigo_postal;
        $cliente->estudio_id = $request->estudio_id;

        $cliente->fecha_nacimiento=date("Y-m-d",strtotime( $request->fecha_nacimiento)); 

echo 'fecha '. $cliente->fecha_nacimiento;
        $cliente->save();

        return redirect()->route('clientes.index')
                  ->with('info', 'cliente Creada');
    }

  //editar un cliente
   public function edit($id)
   {
      $cliente = Cliente::find($id);
      $calle = Calle::find($cliente->calle_id);
      $colonia = Colonia::find($calle->colonia_id);
      $ciudad = Ciudad::find($colonia->ciudad_id);
      $estado = Estado::find($ciudad->estado_id);
      $estudio = Estudio::find($cliente->estudio_id);
      $cliente->calle = $calle->nombre;
      $cliente->estudio = $estudio->nombre;
      $cliente->colonia = $colonia->nombre;
      $cliente->ciudad = $ciudad->nombre;
      $cliente->estado = $estado->nombre;
      /*$cliente = DB::table('clientes')
            ->join('calles', 'clientes.calle_id', '=', 'calles.id')
            ->join('estudios', 'clientes.estudio_id', '=', 'estudios.id')
            ->join('colonias', 'calles.colonia_id', '=', 'colonias.id')
            ->join('ciudads', 'colonias.ciudad_id', '=', 'ciudads.id')
            ->join('estados', 'ciudads.estado_id', '=', 'estados.id')
            ->select('clientes.*', 'calles.nombre AS calle', 'estudios.nombre AS estudio',
              'colonias.nombre AS colonia','ciudads.nombre AS ciudad','estados.nombre AS estado')
             ->where('clientes.id','=', $id)
            ->get();*/
     // echo "datos".$cliente;
      return view('clientes.edit', compact('cliente'));
   } 
    //actualizar el cliente
    public function update(ClienteRequest $request, $id)
    {
        $cliente = Cliente::find($id);

         $cliente->nombre = $request->nombre;
        $cliente->apellido_paterno = $request->apellido_paterno;
        $cliente->apellido_materno = $request->apellido_materno;
      //  $cliente->fecha_nacimiento = $request->fecha_nacimiento;
        $cliente->calle_id = $request->calle_id;
        $cliente->num_ext = $request->num_ext;
        $cliente->codigo_postal = $request->codigo_postal;
        $cliente->estudio_id = $request->estudio_id;

         $cliente->fecha_nacimiento=date("Y-m-d",strtotime( $request->fecha_nacimiento)); 

echo 'fecha '. $cliente->fecha_nacimiento;

        $cliente->save();

        return redirect()->route('clientes.index')
                  ->with('info', 'cliente actualizada');
    }

   //ver un cliente
   public function show($id)
   {
   		$cliente = Cliente::find($id);
   		return view('clientes.show', compact('cliente'));
   } 

   //eliminar un cliente
   public function destroy($id)
   {
   		$cliente = Cliente::find($id);
   		$cliente->delete();

   		return back()->with('info', 'cliente eliminada');
   } 
}
