<?php

namespace RegClientes\Http\Controllers;

use Illuminate\Http\Request;
use RegClientes\Estudio;
use RegClientes\Http\Requests\EstudioRequest;
use DB;//autocomplete hasta l imput
use Response;
use Illuminate\Support\Facades\Input;

class EstudioController extends Controller
{
    //pagina principal
    public function index()
    {
    	$estudios = Estudio::orderBy('id','DESC')->paginate();
    	return view('estudios.index', compact('estudios'));
    }

    //crear estudio
    public function create()
    {
      return view('estudios.create');
    }
    //guardar el nuevo estudio
    public function store(EstudioRequest $request)
    {
        $estudio = new Estudio;

        $estudio->nombre = $request->nombre;
        $estudio->precio = $request->precio;

        $estudio->save();

        return redirect()->route('estudios.index')
                  ->with('info', 'Estudio Creado');
    }

  //editar un estudio
   public function edit($id)
   {
      $estudio = Estudio::find($id);
      return view('estudios.edit', compact('estudio'));
   } 
    //actualizar el estudio
    public function update(EstudioRequest $request, $id)
    {
        $estudio = Estudio::find($id);

        $estudio->nombre = $request->nombre;
        $estudio->precio = $request->precio;

        $estudio->save();

        return redirect()->route('estudios.index')
                  ->with('info', 'Estudio actualizado');
    }

   //ver un estudio
   public function show($id)
   {
   		$estudio = Estudio::find($id);
   		return view('estudios.show', compact('estudio'));
   } 

   //eliminar un estudio
   public function destroy($id)
   {
   		$estudio = Estudio::find($id);
   		$estudio->delete();

   		return back()->with('info', 'Estudio eliminado');
   } 

   public function autocompleteEstudio(Request $request)
   {
      $term = $request->term;
       $results[]  = ['id' => '0','value' => 'Estudio'];

      $queries = DB::table('estudios') 
      ->where('nombre', 'like', '%'.$term.'%') 
      ->take(6)->get();

      foreach ($queries as $query)
      {
          $results[] = ['id' => $query->id, 'value' => $query->nombre]; //you can take custom values as you want
      }
      return response()->json($results);
  }
}
