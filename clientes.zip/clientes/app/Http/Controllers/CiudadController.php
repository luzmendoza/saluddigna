<?php

namespace RegClientes\Http\Controllers;

use Illuminate\Http\Request;
use RegClientes\Ciudad;
use RegClientes\Http\Requests\CiudadRequest;
use RegClientes\Estado;
use DB;//autocomplete hasta l imput
use Response;
use Illuminate\Support\Facades\Input;

class CiudadController extends Controller
{
    //pagina principal
    public function index()
    {
    	$ciudades = Ciudad::orderBy('id','DESC')->paginate();
    	return view('ciudades.index', compact('ciudades'));
    }
    //crear ciudad
    public function create()
    {
       $ciudad = new Ciudad;
      $ciudad->estado = '';
      $ciudad->estado_id = 0;
      return view('ciudades.create',  compact('ciudad') );
    }
    //guardar el nuevo ciudad
    public function store(CiudadRequest $request)
    {
        $ciudad = new Ciudad;

        $ciudad->nombre = $request->nombre;
        $ciudad->estado_id = $request->estado_id;

        $ciudad->save();

        return redirect()->route('ciudades.index')
                  ->with('info', 'Ciudad Creada');
    }

  //editar un ciudad
   public function edit($id)
   {
      $ciudad = Ciudad::find($id);
      $estado = Estado::find($ciudad->estado_id);
      $ciudad->estado = $estado->nombre;
     // echo "datos".$ciudad;
      return view('ciudades.edit', compact('ciudad'));
   } 
    //actualizar el ciudad
    public function update(CiudadRequest $request, $id)
    {
        $ciudad = Ciudad::find($id);

        $ciudad->nombre = $request->nombre;
        $ciudad->estado_id = $request->estado_id;

        $ciudad->save();

        return redirect()->route('ciudades.index')
                  ->with('info', 'Ciudad actualizada');
    }

   //ver un ciudad
   public function show($id)
   {
   		$ciudad = Ciudad::find($id);
   		return view('ciudades.show', compact('ciudad'));
   } 

   //eliminar un ciudad
   public function destroy($id)
   {
   		$ciudad = Ciudad::find($id);
   		$ciudad->delete();

   		return back()->with('info', 'Ciudad eliminada');
   } 


public function autocompleteCiudad(Request $request)
   {
    $term = $request->term;
     $results[]  = ['id' => '0','value' => 'Ciudad'];

    $queries = DB::table('ciudads') 
    ->where('nombre', 'like', '%'.$term.'%') 
    ->take(6)->get();

    foreach ($queries as $query)
    {
        $results[] = ['id' => $query->id, 'value' => $query->nombre]; //you can take custom values as you want
    }
    return response()->json($results);
  }
}
