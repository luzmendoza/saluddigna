<?php

namespace RegClientes\Http\Controllers;

use RegClientes\Http\Requests\CalleRequest;
use RegClientes\Calle;
use RegClientes\Colonia;
use DB;//autocomplete hasta l imput
use Response;
use Illuminate\Support\Facades\Input;

use Illuminate\Http\Request;

class CalleController extends Controller
{
    //pagina principal
    public function index()
    {
    	$calles = Calle::orderBy('id','DESC')->paginate();
    	return view('calles.index', compact('calles'));
    }
    //crear calle
    public function create()
    {
       $calle = new Calle;
      $calle->colonia = '';
      $calle->colonia_id = 0;
      return view('calles.create',  compact('calle') );
    }
    //guardar el nuevo calle
    public function store(CalleRequest $request)
    {
        $calle = new calle;

        $calle->nombre = $request->nombre;
        $calle->colonia_id = $request->colonia_id;

        $calle->save();

        return redirect()->route('calles.index')
                  ->with('info', 'calle Creada');
    }

  //editar un calle
   public function edit($id)
   {
      $calle = Calle::find($id);
      $colonia = Colonia::find($calle->colonia_id);
      $calle->colonia = $colonia->nombre;
     // echo "datos".$calle;
      return view('calles.edit', compact('calle'));
   } 
    //actualizar el calle
    public function update(CalleRequest $request, $id)
    {
        $calle = Calle::find($id);

        $calle->nombre = $request->nombre;
        $calle->colonia_id = $request->colonia_id;

        $calle->save();

        return redirect()->route('calles.index')
                  ->with('info', 'calle actualizada');
    }

   //ver un calle
   public function show($id)
   {
   		$calle = Calle::find($id);
   		return view('calles.show', compact('calle'));
   } 

   //eliminar un calle
   public function destroy($id)
   {
   		$calle = Calle::find($id);
   		$calle->delete();

   		return back()->with('info', 'calle eliminada');
   } 

   public function autocompleteCalle(Request $request)
   {
      $term = $request->term;
       $results[]  = ['id' => '0','value' => 'Calle'];

      $queries = DB::table('calles')
      ->join('colonias', 'calles.colonia_id', '=', 'colonias.id')
      ->join('ciudads', 'colonias.ciudad_id', '=', 'ciudads.id')
      ->join('estados', 'ciudads.estado_id', '=', 'estados.id')
      ->select('calles.*', 'colonias.nombre AS colonia','ciudads.nombre AS ciudad',
        'estados.nombre AS estado')
      ->where('calles.nombre', 'like', '%'.$term.'%') 
      ->take(6)->get();

      foreach ($queries as $query)
      {
          $results[] = ['id' => $query->id, 'value' => $query->nombre,
                        'colonia' => $query->colonia, 'ciudad' => $query->ciudad,
                        'estado' => $query->estado]; //you can take custom values as you want
      }
      return response()->json($results);
  }
}
