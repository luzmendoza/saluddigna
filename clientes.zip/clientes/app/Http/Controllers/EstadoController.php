<?php

namespace RegClientes\Http\Controllers;

use Illuminate\Http\Request;
use RegClientes\Estado;
use RegClientes\Http\Requests\EstadoRequest;
use DB;//autocomplete hasta l imput
use Response;
use Illuminate\Support\Facades\Input;

class EstadoController extends Controller
{
    //
    //pagina principal
    public function index()
    {
    	$estados = Estado::orderBy('id','DESC')->paginate();
    	return view('estados.index', compact('estados'));
    }
    //crear estado
    public function create()
    {
      return view('estados.create');
    }
    //guardar el nuevo estado
    public function store(estadoRequest $request)
    {
        $estado = new Estado;

        $estado->nombre = $request->nombre;

        $estado->save();

        return redirect()->route('estados.index')
                  ->with('info', 'Estado Creado');
    }

  //editar un estado
   public function edit($id)
   {
      $estado = Estado::find($id);
      return view('estados.edit', compact('estado'));
   } 
    //actualizar el estado
    public function update(estadoRequest $request, $id)
    {
        $estado = Estado::find($id);

        $estado->nombre = $request->nombre;

        $estado->save();

        return redirect()->route('estados.index')
                  ->with('info', 'Estado actualizado');
    }

   //ver un estado
   public function show($id)
   {
   		$estado = Estado::find($id);
   		return view('estados.show', compact('estado'));
   } 

   //eliminar un estado
   public function destroy($id)
   {
   		$estado = Estado::find($id);
   		$estado->delete();

   		return back()->with('info', 'Estado eliminado');
   } 

public function autocomplete(Request $request)
   {
    $term = $request->term;
     $results[]  = ['id' => '0','value' => 'Estados'];

    $queries = DB::table('estados') 
    ->where('nombre', 'like', '%'.$term.'%') 
    ->take(6)->get();

    foreach ($queries as $query)
    {
        $results[] = ['id' => $query->id, 'value' => $query->nombre]; //you can take custom values as you want
    }
    return response()->json($results);
  }

}
