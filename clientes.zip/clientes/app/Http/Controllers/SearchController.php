<?php
public function autocomplete(){
	$term = Input::get('term');
	
	$results = array();
	
	$queries = DB::table('estados')
		->where('nombre', 'LIKE', '%'.$term.'%')
		->take(5)->get();
	
	foreach ($queries as $query)
	{
	    $results[] = [ 'id' => $query->id, 'value' => $query->nombre];
	}
return Response::json($results);
}
?>