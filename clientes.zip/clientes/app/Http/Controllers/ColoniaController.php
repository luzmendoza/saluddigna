<?php

namespace RegClientes\Http\Controllers;

use Illuminate\Http\Request;
use RegClientes\Ciudad;
use RegClientes\Http\Requests\ColoniaRequest;
use RegClientes\Colonia;
use DB;//autocomplete hasta l imput
use Response;
use Illuminate\Support\Facades\Input;


class ColoniaController extends Controller
{
    //
    //pagina principal
    public function index()
    {
    	$colonias = Colonia::orderBy('id','DESC')->paginate();
    	return view('colonias.index', compact('colonias'));
    }
    //crear colonia
    public function create()
    {
       $colonia = new Colonia;
      $colonia->ciudad = '';
      $colonia->ciudad_id = 0;
      return view('colonias.create',  compact('colonia') );
    }
    //guardar el nuevo colonia
    public function store(ColoniaRequest $request)
    {
        $colonia = new Colonia;

        $colonia->nombre = $request->nombre;
        $colonia->ciudad_id = $request->ciudad_id;

        $colonia->save();

        return redirect()->route('colonias.index')
                  ->with('info', 'colonia Creada');
    }

  //editar un colonia
   public function edit($id)
   {
      $colonia = Colonia::find($id);
      $ciudad = Ciudad::find($colonia->ciudad_id);
      $colonia->ciudad = $ciudad->nombre;
     // echo "datos".$colonia;
      return view('colonias.edit', compact('colonia'));
   } 
    //actualizar el colonia
    public function update(ColoniaRequest $request, $id)
    {
        $colonia = Colonia::find($id);

        $colonia->nombre = $request->nombre;
        $colonia->ciudad_id = $request->ciudad_id;

        $colonia->save();

        return redirect()->route('colonias.index')
                  ->with('info', 'colonia actualizada');
    }

   //ver un colonia
   public function show($id)
   {
   		$colonia = Colonia::find($id);
   		return view('colonias.show', compact('colonia'));
   } 

   //eliminar un colonia
   public function destroy($id)
   {
   		$colonia = Colonia::find($id);
   		$colonia->delete();

   		return back()->with('info', 'colonia eliminada');
   } 

   public function autocompleteColonia(Request $request)
   {
      $term = $request->term;
       $results[]  = ['id' => '0','value' => 'Colonia'];

      $queries = DB::table('colonias') 
      ->where('nombre', 'like', '%'.$term.'%') 
      ->take(6)->get();

      foreach ($queries as $query)
      {
          $results[] = ['id' => $query->id, 'value' => $query->nombre]; //you can take custom values as you want
      }
      return response()->json($results);
  }
}
