<?php

namespace RegClientes;

use Illuminate\Database\Eloquent\Model;

class Colonia extends Model
{
    //
     protected $fillable = [
        'nombre', 'ciudad_id'
    ];
}
