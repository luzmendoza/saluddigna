<?php

namespace RegClientes;

use Illuminate\Database\Eloquent\Model;

class Ciudad extends Model
{
    //
    protected $fillable = [
        'nombre', 'estado_id'
    ];

    //relacion con estado
    /*public function estados()
    {
        return $this->belongsTo('Estado', 'estado_id', 'id');
    }*/
}
