<?php

namespace RegClientes;

use Illuminate\Database\Eloquent\Model;

class Calle extends Model
{
    //
    protected $fillable = [
        'nombre', 'colonia_id'
    ];
}
