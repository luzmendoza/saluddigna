<?php

namespace RegClientes;

use Illuminate\Database\Eloquent\Model;

class Estudio extends Model
{
    //
    protected $fillable = [
        'nombre', 'precio'
    ];
}
