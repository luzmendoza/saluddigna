<div class="form-group">
	{!! Form::label('nombre', 'Nombre de la ciudad') !!}
	{!! Form::text('nombre', null, ['class' => 'form-control', 'maxlength' => 50]) !!}
</div>

<div class="form-group">
	{!! Form::label('estado', 'Nombre del estado') !!}
	{{ Form::hidden('estado_id', $ciudad->estado_id, array('id' => 'estado_id')) }}
	
    {{ Form::text('estado', $ciudad->estado, ['id' => 'estado', 'placeholder' => 'Seleccionar estado', 'class' => 'form-control'])}}


</div>


<div class="form-group">
	{!! Form::submit('GUARDAR', ['class' => 'btn btn-primary']) !!}
	<a href="{{ route('ciudades.index')}}" class="btn btn-primary pull-right"> CANCELAR </a>
</div>
