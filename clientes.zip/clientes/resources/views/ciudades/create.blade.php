@extends('layout')

@section('content')

<div class="col-sm-8">
	<h2>
		Nuevo Ciudad
		<a href="{{ route('ciudades.index')}}" class="btn btn-primary pull-right"> Listado</a>
	</h2>
	
	@include('ciudades.fragments.error')

	{!! Form::open(['route' => 'ciudades.store']) !!}

		@include('ciudades.fragments.form')

	{!! Form::close() !!}

</div>
<div class="col-sm-4">

@include('ciudades.fragments.aside')
	
</div>

@endsection