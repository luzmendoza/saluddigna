@extends('layout')

@section('content')

<div class="col-sm-10">
	<h2>
		Listado de Ciudades
		<a href="{{ route('ciudades.create')}}" class="btn btn-primary pull-right">Nuevo</a>
	</h2>

	@include('ciudades.fragments.info')

	<table class="table table-hover table-striped">
		<thead>
			<tr>
				<th width="20px">ID</th>
				<th>Nombre</th>
				<th colspan="2">&nbsp;</th>
			</tr>
		</thead>
		<tbody>
			@foreach($ciudades as $ciudad)
			<tr>
				<td>{{ $ciudad->id }}</td>
				<td>{{ $ciudad->nombre }}</td>
				
				<td>
					<a href="{{ route('ciudades.edit',$ciudad->id)}}" class="btn btn-primary pull-right"> Editar</a>
				</td>
				<td>
					<form action="{{ route('ciudades.destroy', $ciudad->id) }}" method="POST", onclick="return confirm('¿Esta seguro de eliminar?')" >
						{{ csrf_field()}} <!--seguridad-->
						<input type="hidden" name="_method" value="DELETE"></input>
						<button class="btn btn-danger pull-right">Borrar</button>
					</form>
				</td>
			</tr>
			@endforeach
		</tbody>
	</table>
	{!! $ciudades->render() !!}

</div>
<div class="col-sm-2">

@include('ciudades.fragments.aside')
	
</div>

@endsection