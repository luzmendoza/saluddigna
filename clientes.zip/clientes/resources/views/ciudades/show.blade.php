@extends('layout')

@section('content')

<div class="col-sm-8">
	<h2>
		{{ $ciudad->nombre }}
		<a href="{{ route('ciudades.edit', $ciudad->id)}}" class="btn btn-primary pull-right"> Editar</a>
	</h2>

</div>
<div class="col-sm-4">

@include('ciudades.fragments.aside')
	
</div>

@endsection