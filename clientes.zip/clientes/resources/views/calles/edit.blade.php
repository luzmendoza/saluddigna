@extends('layout')

@section('content')

<div class="col-sm-8">
	<h2>
		Editar Calle
		<a href="{{ route('calles.index')}}" class="btn btn-primary pull-right"> Listado</a>
	</h2>
	
	@include('calles.fragments.error')

	{!! Form::model($calle, ['route' => ['calles.update', $calle->id], 'method' => 'PUT']) !!}


		@include('calles.fragments.form')

	{!! Form::close() !!}

</div>
<div class="col-sm-4">

@include('calles.fragments.aside')
	
</div>

@endsection