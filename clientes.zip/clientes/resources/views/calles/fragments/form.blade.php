<div class="form-group">
	{!! Form::label('nombre', 'Nombre de la Calle') !!}
	{!! Form::text('nombre', null, ['class' => 'form-control', 'maxlength' => 50]) !!}
</div>

<div class="form-group">
	{!! Form::label('colonia', 'Nombre de la Colonia') !!}
	{{ Form::hidden('colonia_id', $calle->colonia_id, array('id' => 'colonia_id')) }}
	
    {{ Form::text('colonia', $calle->colonia, ['id' => 'colonia', 'placeholder' => 'Seleccionar colonia', 'class' => 'form-control'])}}


</div>


<div class="form-group">
	{!! Form::submit('GUARDAR', ['class' => 'btn btn-primary']) !!}
	<a href="{{ route('calles.index')}}" class="btn btn-primary pull-right"> CANCELAR </a>
</div>
