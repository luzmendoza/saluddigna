@extends('layout')

@section('content')

<div class="col-sm-8">
	<h2>
		{{ $calle->nombre }}
		<a href="{{ route('calles.edit', $calle->id)}}" class="btn btn-primary pull-right"> Editar</a>
	</h2>

</div>
<div class="col-sm-4">

@include('calles.fragments.aside')
	
</div>

@endsection