@extends('layout')

@section('content')

<div class="col-sm-8">
	<h2>
		Nuevo Calle
		<a href="{{ route('calles.index')}}" class="btn btn-primary pull-right"> Listado</a>
	</h2>
	
	@include('calles.fragments.error')

	{!! Form::open(['route' => 'calles.store']) !!}

		@include('calles.fragments.form')

	{!! Form::close() !!}

</div>
<div class="col-sm-4">

@include('calles.fragments.aside')
	
</div>

@endsection