@extends('layout')

@section('content')

<div class="col-sm-10">
	<h2>
		Listado de Calles
		<a href="{{ route('calles.create')}}" class="btn btn-primary pull-right">Nuevo</a>
	</h2>

	@include('calles.fragments.info')

	<table class="table table-hover table-striped">
		<thead>
			<tr>
				<th width="20px">ID</th>
				<th>Nombre</th>
				<th colspan="2">&nbsp;</th>
			</tr>
		</thead>
		<tbody>
			@foreach($calles as $calle)
			<tr>
				<td>{{ $calle->id }}</td>
				<td>{{ $calle->nombre }}</td>
				
				<td>
					<a href="{{ route('calles.edit',$calle->id)}}" class="btn btn-primary pull-right"> Editar</a>
				</td>
				<td>
					<form action="{{ route('calles.destroy', $calle->id) }}" method="POST", onclick="return confirm('¿Esta seguro de eliminar?')" >
						{{ csrf_field()}} <!--seguridad-->
						<input type="hidden" name="_method" value="DELETE"></input>
						<button class="btn btn-danger pull-right">Borrar</button>
					</form>
				</td>
			</tr>
			@endforeach
		</tbody>
	</table>
	{!! $calles->render() !!}

</div>
<div class="col-sm-2">

@include('calles.fragments.aside')
	
</div>

@endsection