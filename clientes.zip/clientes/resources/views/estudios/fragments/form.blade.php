<div class="form-group">
	{!! Form::label('nombre', 'Nombre del estudio') !!}
	{!! Form::text('nombre', null, ['class' => 'form-control', 'maxlength' => 50 ]) !!}
</div>

<div class="form-group">
	{!! Form::label('precio', 'Precio del estudio') !!}
	{!! Form::text('precio', null, ['class' => 'form-control', 'maxlength' => 9, 'onkeypress'=>'return valida(event)']) !!}
</div>

<div class="form-group">
	{!! Form::submit('GUARDAR', ['class' => 'btn btn-primary']) !!}
	<a href="{{ route('estudios.index')}}" class="btn btn-primary pull-right"> CANCELAR </a>
</div>
