@extends('layout')

@section('content')

<div class="col-sm-8">
	<h2>
		Editar Estudio
		<a href="{{ route('estudios.index')}}" class="btn btn-primary pull-right"> Listado</a>
	</h2>
	
	@include('estudios.fragments.error')

	{!! Form::model($estudio, ['route' => ['estudios.update', $estudio->id], 'method' => 'PUT']) !!}


		@include('estudios.fragments.form')

	{!! Form::close() !!}

</div>
<div class="col-sm-4">

@include('estudios.fragments.aside')
	
</div>

@endsection