@extends('layout')

@section('content')

<div class="col-sm-8">
	<h2>
		{{ $estudio->nombre }}
		<a href="{{ route('estudios.edit', $estudio->id)}}" class="btn btn-primary pull-right"> Editar</a>
	</h2>
	<p>
		{{ $estudio->precio }}
	</p>

</div>
<div class="col-sm-4">

@include('estudios.fragments.aside')
	
</div>

@endsection