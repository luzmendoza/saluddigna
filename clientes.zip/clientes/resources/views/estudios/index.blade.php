@extends('layout')

@section('content')

<div class="col-sm-10">
	<h2>
		Listado de Estudios
		<a href="{{ route('estudios.create')}}" class="btn btn-primary pull-right">Nuevo</a>
	</h2>

	@include('estudios.fragments.info')

	<table class="table table-hover table-striped">
		<thead>
			<tr>
				<th width="20px">ID</th>
				<th>Nombre</th>
				<th>Precio</th>
				<th colspan="2">&nbsp;</th>
			</tr>
		</thead>
		<tbody>
			@foreach($estudios as $estudio)
			<tr>
				<td>{{ $estudio->id }}</td>
				<td>{{ $estudio->nombre }}</td>
				<td>{{ $estudio->precio }}</td>
				
				<td>
					<a href="{{ route('estudios.edit',$estudio->id)}}" class="btn btn-primary pull-right"> Editar</a>
				</td>
				<td>
					<form action="{{ route('estudios.destroy', $estudio->id) }}" method="POST", onclick="return confirm('¿Esta seguro de eliminar?')" >
						{{ csrf_field()}} <!--seguridad-->
						<input type="hidden" name="_method" value="DELETE"></input>
						<button class="btn btn-danger pull-right">Borrar</button>
					</form>
				</td>
			</tr>
			@endforeach
		</tbody>
	</table>
	{!! $estudios->render() !!}

</div>
<div class="col-sm-2">

@include('estudios.fragments.aside')
	
</div>

@endsection
