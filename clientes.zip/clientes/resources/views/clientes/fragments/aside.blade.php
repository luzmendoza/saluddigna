<p class="alert alert-info">
	Desde aqui podemos crear, eliminar, listar y editar los clientes.
</p>