<div class="form-group">
	{!! Form::label('nombre', 'Nombre') !!}
	{!! Form::text('nombre', null, ['class' => 'form-control']) !!}
</div>
<div class="form-group">
	{!! Form::label('apellido_paterno', 'Apellido Paterno') !!}
	{!! Form::text('apellido_paterno', null, ['class' => 'form-control']) !!}
</div>
<div class="form-group">
	{!! Form::label('apellido_materno', 'Apellido Materno') !!}
	{!! Form::text('apellido_materno', null, ['class' => 'form-control']) !!}
</div>
<div class="form-group">
	{!! Form::label('fecha_nacimiento', 'Fecha de Nacimiento') !!}
	{!! Form::text('fecha_nacimiento', Carbon\Carbon::parse($cliente->fecha_nacimiento)->format('d/m/Y') , ['id' =>'fecha_nacimiento','class' => 'form-control']) !!}
</div>


<div class="form-group">
{!! Form::label('direccion', 'Dirección') !!}
</div>
<div class="form-group">

	{!! Form::label('calle', 'Calle') !!}
	{{ Form::hidden('calle_id', $cliente->calle_id, array('id' => 'calle_id')) }}
	
    {{ Form::text('calle', $cliente->calle, ['id' => 'calle', 'placeholder' => 'Seleccionar calle', 'class' => 'form-control'])}}
    </div>
<div class="form-group">
{!! Form::label('colonia', 'Colonia') !!}
    {{ Form::text('colonia', $cliente->colonia, ['readonly'=>'readonly', 'class' => 'form-control'])}}
    </div>
    <div class="form-group">
    {!! Form::label('ciudad', 'Ciudad') !!}
     {{ Form::text('ciudad', $cliente->ciudad, ['readonly'=>'readonly', 'class' => 'form-control'])}}
</div>
     <div class="form-group">
     {!! Form::label('estado', 'Estado') !!}
      {{ Form::text('estado', $cliente->estado, ['readonly'=>'readonly', 'class' => 'form-control'])}}


</div>

<div class="form-group">
	{!! Form::label('num_ext', 'No. Ext.') !!}
	{!! Form::text('num_ext', null, ['class' => 'form-control', 'maxlength' => 5, 'onkeypress'=>'return valida(event)' ]) !!}
</div>

<div class="form-group">
	{!! Form::label('codigo_postal', 'CP') !!}
	{!! Form::text('codigo_postal', null, ['class' => 'form-control', 'maxlength' => 5, 'onkeypress'=>'return valida(event)' ]) !!}
</div>

<div class="form-group">
	{!! Form::label('estudio', 'Estudio a realizar') !!}
	{{ Form::hidden('estudio_id', $cliente->estudio_id, array('id' => 'estudio_id')) }}
	
    {{ Form::text('estudio', $cliente->estudio, ['id' => 'estudio', 'placeholder' => 'Seleccionar estudio', 'class' => 'form-control'])}}

    </div>


<div class="form-group">
	{!! Form::submit('GUARDAR', ['class' => 'btn btn-primary']) !!}
	<a href="{{ route('clientes.index')}}" class="btn btn-primary pull-right"> CANCELAR </a>
</div>
