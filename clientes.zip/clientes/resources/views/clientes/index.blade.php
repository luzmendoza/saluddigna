@extends('layout')

@section('content')

<div class="col-sm-10">
	<h2>
		Listado de Clientes
		<a href="{{ route('clientes.create')}}" class="btn btn-primary pull-right">Nuevo</a>
	</h2>

	@include('clientes.fragments.info')

	<table class="table table-hover table-striped">
		<thead>
			<tr>
				<th width="20px">ID</th>
				<th>Nombre</th>
				<th>Fecha de Nacimiento</th>
				<th>Dirección</th>
				<th>Estudio a realizar</th>
				<th colspan="2">&nbsp;</th>
			</tr>
		</thead>
		<tbody>
			@foreach($clientes as $cliente)
			<tr>
				<td>{{ $cliente->id }}</td>
				<td>{{ $cliente->nombre . ' '. $cliente->apellido_paterno . ' '. $cliente->apellido_materno  }}</td>
				<td>{{ Carbon\Carbon::parse($cliente->fecha_nacimiento)->format('d/m/Y')  }}</td>
				<td>{{ 'Calle '.$cliente->calle .' No. Ext. '.$cliente->num_ext. ' Colonia '.$cliente->colonia .' CP. '.$cliente->codigo_postal .' '.$cliente->ciudad .' '.$cliente->estado}}</td>
				<td>{{ $cliente->estudio }}</td>
				
				<td>
					<a href="{{ route('clientes.edit',$cliente->id)}}" class="btn btn-primary"> Editar</a>
				</td>
				<td>
					<form action="{{ route('clientes.destroy', $cliente->id) }}" method="POST", onclick="return confirm('¿Esta seguro de eliminar?')" >
						{{ csrf_field()}} <!--seguridad-->
						<input type="hidden" name="_method" value="DELETE"></input>
						<button class="btn btn-danger">Borrar</button>
					</form>
				</td>
			</tr>
			@endforeach
		</tbody>
	</table>
	

</div>
<div class="col-sm-2">

@include('clientes.fragments.aside')
	
</div>

@endsection