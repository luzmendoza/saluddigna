@extends('layout')

@section('content')

<div class="col-sm-8">
	<h2>
		Nuevo Cliente
		<a href="{{ route('clientes.index')}}" class="btn btn-primary pull-right"> Listado</a>
	</h2>
	
	@include('clientes.fragments.error')

	{!! Form::open(['route' => 'clientes.store']) !!}

		@include('clientes.fragments.form')

	{!! Form::close() !!}

</div>
<div class="col-sm-4">

@include('clientes.fragments.aside')
	
</div>

@endsection