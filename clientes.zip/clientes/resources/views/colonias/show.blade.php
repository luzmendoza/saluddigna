@extends('layout')

@section('content')

<div class="col-sm-8">
	<h2>
		{{ $colonia->nombre }}
		<a href="{{ route('colonias.edit', $colonia->id)}}" class="btn btn-primary pull-right"> Editar</a>
	</h2>

</div>
<div class="col-sm-4">

@include('colonias.fragments.aside')
	
</div>

@endsection