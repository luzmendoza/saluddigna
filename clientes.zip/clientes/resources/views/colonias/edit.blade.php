@extends('layout')

@section('content')

<div class="col-sm-8">
	<h2>
		Editar Colonia
		<a href="{{ route('colonias.index')}}" class="btn btn-primary pull-right"> Listado</a>
	</h2>
	
	@include('colonias.fragments.error')

	{!! Form::model($colonia, ['route' => ['colonias.update', $colonia->id], 'method' => 'PUT']) !!}


		@include('colonias.fragments.form')

	{!! Form::close() !!}

</div>
<div class="col-sm-4">

@include('colonias.fragments.aside')
	
</div>

@endsection