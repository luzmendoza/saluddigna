<div class="form-group">
	{!! Form::label('nombre', 'Nombre de la colonia') !!}
	{!! Form::text('nombre', null, ['class' => 'form-control', 'maxlength' => 50]) !!}
</div>

<div class="form-group">
	{!! Form::label('ciudad', 'Nombre de la ciudad') !!}
	{{ Form::hidden('ciudad_id', $colonia->ciudad_id, array('id' => 'ciudad_id')) }}
	
    {{ Form::text('ciudad', $colonia->ciudad, ['id' => 'ciudad', 'placeholder' => 'Seleccionar ciudad', 'class' => 'form-control'])}}


</div>


<div class="form-group">
	{!! Form::submit('GUARDAR', ['class' => 'btn btn-primary']) !!}
	<a href="{{ route('colonias.index')}}" class="btn btn-primary pull-right"> CANCELAR </a>
</div>
