@extends('layout')

@section('content')

<div class="col-sm-8">
	<h2>
		{{ $estado->nombre }}
		<a href="{{ route('estados.edit', $estado->id)}}" class="btn btn-primary pull-right"> Editar</a>
	</h2>

</div>
<div class="col-sm-4">

@include('estados.fragments.aside')
	
</div>

@endsection