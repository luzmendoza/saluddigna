@extends('layout')

@section('content')

<div class="col-sm-8">
	<h2>
		Nuevo Estado
		<a href="{{ route('estados.index')}}" class="btn btn-primary pull-right"> Listado</a>
	</h2>
	
	@include('estados.fragments.error')

	{!! Form::open(['route' => 'estados.store']) !!}

		@include('estados.fragments.form')

	{!! Form::close() !!}

</div>
<div class="col-sm-4">

@include('estados.fragments.aside')
	
</div>

@endsection