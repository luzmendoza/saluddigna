@extends('layout')

@section('content')

<div class="col-sm-10">
	<h2>
		Listado de Estados
		<a href="{{ route('estados.create')}}" class="btn btn-primary pull-right">Nuevo</a>
	</h2>

	@include('estados.fragments.info')

	<table class="table table-hover table-striped">
		<thead>
			<tr>
				<th width="20px">ID</th>
				<th>Nombre</th>
				<th colspan="2">&nbsp;</th>
			</tr>
		</thead>
		<tbody>
			@foreach($estados as $estado)
			<tr>
				<td>{{ $estado->id }}</td>
				<td>{{ $estado->nombre }}</td>
				
				<td>
					<a href="{{ route('estados.edit',$estado->id)}}" class="btn btn-primary pull-right"> Editar</a>
				</td>
				<td>
					<form action="{{ route('estados.destroy', $estado->id) }}" method="POST", onclick="return confirm('¿Esta seguro de eliminar?')" >
						{{ csrf_field()}} <!--seguridad-->
						<input type="hidden" name="_method" value="DELETE"></input>
						<button class="btn btn-danger pull-right">Borrar</button>
					</form>
				</td>
			</tr>
			@endforeach
		</tbody>
	</table>
	{!! $estados->render() !!}

</div>
<div class="col-sm-2">

@include('estados.fragments.aside')
	
</div>

@endsection