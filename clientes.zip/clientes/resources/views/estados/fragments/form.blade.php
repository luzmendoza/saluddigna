<div class="form-group">
	{!! Form::label('nombre', 'Nombre del estado') !!}
	{!! Form::text('nombre', null, ['class' => 'form-control', 'maxlength' => 50]) !!}
</div>


<div class="form-group">
	{!! Form::submit('GUARDAR', ['class' => 'btn btn-primary']) !!}
	<a href="{{ route('estados.index')}}" class="btn btn-primary pull-right"> CANCELAR </a>
</div>