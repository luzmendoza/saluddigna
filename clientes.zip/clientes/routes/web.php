<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::resource('estudios', 'EstudioController');

Route::get('/autocompleteEstudio', array('as' => 'autocompleteEstudio', 'uses'=>'EstudioController@autocompleteEstudio'));


Route::resource('estados', 'EstadoController');

Route::get('/autocomplete', array('as' => 'autocomplete', 'uses'=>'EstadoController@autocomplete'));

Route::resource('ciudades', 'CiudadController');

Route::get('/autocompleteCiudad', array('as' => 'autocompleteCiudad', 'uses'=>'CiudadController@autocompleteCiudad'));


Route::resource('colonias', 'ColoniaController');

Route::get('/autocompleteColonia', array('as' => 'autocompleteColonia', 'uses'=>'ColoniaController@autocompleteColonia'));

Route::resource('calles', 'CalleController');

Route::get('/autocompleteCalle', array('as' => 'autocompleteCalle', 'uses'=>'CalleController@autocompleteCalle'));

Route::resource('clientes', 'ClienteController');

?>